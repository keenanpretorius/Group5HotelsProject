﻿using System;

public class ReportController
{
	public ReportController()
	{

	}
}
