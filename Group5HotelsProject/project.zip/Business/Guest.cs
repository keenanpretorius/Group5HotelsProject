﻿using System;

namespace Group5HotelsProject.Business
{
    public class Guest : Person
    {
        #region Attributes
        private int guestID;
        private string postalCode;
        private string idPassportNumber;
        private string loyaltyStatus;
        #endregion

        #region Properties
        public int GuestID
        {
            get { return guestID; }
            set { guestID = value; }
        }

        public string PostalCode
        {
            get { return postalCode; }
            set { postalCode = value; }
        }

        public string IDPassportNumber
        {
            get { return idPassportNumber; }
            set { idPassportNumber = value; }
        }

        public string LoyaltyStatus
        {
            get { return loyaltyStatus; }
            set { loyaltyStatus = value; }
        }
        #endregion

        #region Constructors
        public Guest()
        {
        }

        public Guest(
            int guestID,
            string firstName,
            string lastName,
            string phoneNumber,
            string email,
            string address,
            string city,
            string postalCode,
            string idPassportNumber
             
        ) : base(guestID, firstName, lastName, phoneNumber, email, address, city)
        {
            this.guestID = guestID;
            this.postalCode = postalCode;
            this.idPassportNumber = idPassportNumber;
            this.loyaltyStatus = null;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return FullName + " (Guest - " + Email + ")";
        }
        #endregion
    }
}
