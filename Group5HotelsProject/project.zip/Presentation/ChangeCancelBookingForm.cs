﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group5HotelsProject.Presentation
{
    public partial class ChangeCancelBookingForm : Form
    {
        public ChangeCancelBookingForm()
        {
            InitializeComponent();
        }

    }
}
